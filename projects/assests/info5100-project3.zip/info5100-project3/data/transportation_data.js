transportation_types = [{"mode":"Car","fatalities":7.28},
{"mode":"Ferry","fatalities":3.17},
{"mode":"Train","fatalities":0.43},
{"mode":"Subway","fatalities":0.24},
{"mode":"Bus","fatalities":0.11},
{"mode":"Airplane","fatalities":0.07}]